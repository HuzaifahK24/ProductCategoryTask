﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace ProductCategoryApp.DAL
{
    public static class DatabaseHelper
    {
        private static readonly string ConnectionString = @"Data Source=DESKTOP-7GOB9FM;Initial Catalog=MachineDb;Integrated Security=True;TrustServerCertificate=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
