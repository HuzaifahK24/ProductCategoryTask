﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProductCategoryApp.DAL;
using ProductCategoryApp.Models;
using System.Collections.Generic;

public class ProductController : Controller
{
    public ActionResult Index(int page = 1, int pageSize = 10)
    {
        var products = new List<Product>();
        int offset = (page - 1) * pageSize;

        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();

            
            SqlCommand countCmd = new SqlCommand("SELECT COUNT(*) FROM Product", con);
            int totalRecords = (int)countCmd.ExecuteScalar();

            
            using (var cmd = new SqlCommand(@"
                SELECT p.ProductId, p.ProductName, c.CategoryId, c.CategoryName
                FROM Product p
                INNER JOIN Category c ON p.CategoryId = c.CategoryId
                ORDER BY p.ProductId
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", con))
            {
                cmd.Parameters.AddWithValue("@Offset", offset);
                cmd.Parameters.AddWithValue("@PageSize", pageSize);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            ProductId = (int)reader["ProductId"],
                            ProductName = reader["ProductName"].ToString(),
                            CategoryId = (int)reader["CategoryId"],
                            CategoryName = reader["CategoryName"].ToString()
                        });
                    }
                }
            }

            
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize);
            ViewBag.CurrentPage = page;
        }

        return View(products);
    }

    public ActionResult Create()
    {
        ViewBag.Categories = GetCategories();
        return View();
    }

    [HttpPost]
    public ActionResult Create(Product product)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("INSERT INTO Product (ProductName, CategoryId) VALUES (@ProductName, @CategoryId)", con))
            {
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }

    public ActionResult Edit(int id)
    {
        Product product = null;
        ViewBag.Categories = GetCategories();
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("SELECT * FROM Product WHERE ProductId = @ProductId", con))
            {
                cmd.Parameters.AddWithValue("@ProductId", id);
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        product = new Product
                        {
                            ProductId = (int)reader["ProductId"],
                            ProductName = reader["ProductName"].ToString(),
                            CategoryId = (int)reader["CategoryId"]
                        };
                    }
                }
            }
        }
        return View(product);
    }

    [HttpPost]
    public ActionResult Edit(Product product)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("UPDATE Product SET ProductName = @ProductName, CategoryId = @CategoryId WHERE ProductId = @ProductId", con))
            {
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.Parameters.AddWithValue("@ProductId", product.ProductId);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }

    public ActionResult Delete(int id)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("DELETE FROM Product WHERE ProductId = @ProductId", con))
            {
                cmd.Parameters.AddWithValue("@ProductId", id);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }

    private List<Category> GetCategories()
    {
        var categories = new List<Category>();
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("SELECT * FROM Category", con))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    categories.Add(new Category
                    {
                        CategoryId = (int)reader["CategoryId"],
                        CategoryName = reader["CategoryName"].ToString()
                    });
                }
            }
        }
        return categories;
    }
}
