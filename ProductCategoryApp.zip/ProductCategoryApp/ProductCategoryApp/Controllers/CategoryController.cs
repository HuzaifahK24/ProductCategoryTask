﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProductCategoryApp.DAL;
using ProductCategoryApp.Models;

public class CategoryController : Controller
{
    public ActionResult Index()
    {
        var categories = new List<Category>();
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("SELECT * FROM Category", con))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    categories.Add(new Category
                    {
                        CategoryId = (int)reader["CategoryId"],
                        CategoryName = reader["CategoryName"].ToString()
                    });
                }
            }
        }
        return View(categories);
    }

    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Create(Category category)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("INSERT INTO Category (CategoryName) VALUES (@CategoryName)", con))
            {
                cmd.Parameters.AddWithValue("@CategoryName", category.CategoryName);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }

    public ActionResult Edit(int id)
    {
        Category category = null;
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("SELECT * FROM Category WHERE CategoryId = @CategoryId", con))
            {
                cmd.Parameters.AddWithValue("@CategoryId", id);
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        category = new Category
                        {
                            CategoryId = (int)reader["CategoryId"],
                            CategoryName = reader["CategoryName"].ToString()
                        };
                    }
                }
            }
        }
        return View(category);
    }

    [HttpPost]
    public ActionResult Edit(Category category)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("UPDATE Category SET CategoryName = @CategoryName WHERE CategoryId = @CategoryId", con))
            {
                cmd.Parameters.AddWithValue("@CategoryName", category.CategoryName);
                cmd.Parameters.AddWithValue("@CategoryId", category.CategoryId);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }

    public ActionResult Delete(int id)
    {
        using (var con = DatabaseHelper.GetConnection())
        {
            con.Open();
            using (var cmd = new SqlCommand("DELETE FROM Category WHERE CategoryId = @CategoryId", con))
            {
                cmd.Parameters.AddWithValue("@CategoryId", id);
                cmd.ExecuteNonQuery();
            }
        }
        return RedirectToAction("Index");
    }
}
